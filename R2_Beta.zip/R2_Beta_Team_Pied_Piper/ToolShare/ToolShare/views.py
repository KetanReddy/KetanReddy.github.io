"""
Views.py
A file that contains all of the executable code for any given url that can
be accessed on the website. Any given view can/will execute operations on the
database or any model in the database before rendering the end product for the
user.

Written by Team Pied Piper
"""
"""Import Section for Views.py"""
from django.contrib.auth import authenticate
from django.contrib.auth import login as LOGIN
from django.contrib.auth import logout as LOGOUT
from django.contrib.auth.models import AnonymousUser
from django.contrib.auth.decorators import login_required
from django.db.utils import OperationalError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.template import loader, Context
from django.views.decorators.csrf import csrf_protect
from django.utils.datastructures import MultiValueDictKeyError
from django.db import IntegrityError
import random
from django.core.mail import send_mail

from ToolShare.models import Person, Address, Shed, Tool, Notification, ShedRequest, ToolRequest, ExtensionRequest, ConfirmationRequest

from decimal import  *

def About(request):
    """
    About / Contact page
    """
    user = request.user
    t = loader.get_template('About_Help.html')
    is_anon = False
    if isinstance(user,AnonymousUser):
        is_anon=True
        c = RequestContext(request,{'is_anon': is_anon})
    else:
        c = RequestContext(
                       request, {
                      'username': user.username,
                      'first_name' : user.first_name,
                      'last_name' : user.last_name,}
                       )
    return HttpResponse(t.render(c))

@login_required(login_url='/Login/')
def AddTool(request):
    """
    This view contains the new tool registration form to be filled out by a user
    to add a tool to their own personal collection as well as automatically
    add the tool to any shed they are a part of.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    user = request.user
    t = loader.get_template('AddTool.html')
    shed_list = []
    if user.sheds is not None:
        shed_list = user.sheds.all()
    toolstring=""
    if user.registered_tools is not None:
        all_entries=user.registered_tools.all()
        for entry in all_entries:
            toolstring+=entry.name
    c = RequestContext(
               request, {
               'shed_list' : shed_list,
               'first_name': user.first_name,
               'last_name': user.last_name
             })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login/')
def AddToolRequest(request):
    """
    This is a middleman view for adding a tool, The information supplied in the
    form is sent here and the tool is created and automatically added to the
    users tool list.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    user = request.user
    name=request.POST['name']
    description=request.POST['description']
    category = request.POST['category']
    pickup_arrangements=request.POST['pickup_arrangements']
    shed = None
    shed_list = []
    if user.sheds is not None:
        shed_list = user.sheds.all()
    if(pickup_arrangements == "Shed"):
        for s in shed_list:
            if s.name == request.POST['shed']:
                shed = s
    special_instructions=request.POST['special_instructions']
    #image=request.POST['image']
    image = ""
    tool=Tool.create(user, name, description, category, pickup_arrangements, special_instructions,image, shed )
    user.register_tool(tool)
    #Create a notification for the home page - can remove later, this is for testing notifications.
    note = Notification.create(user, 'You have successfully registered ' + tool.name, 1)
    user.add_notification(note)

    return HttpResponseRedirect('/Tools/')

@login_required(login_url='/Login')
def BorrowTool(request):
    """
    This view is called when a user requests a tool from another user. The url
    will be in the format: /BorrowTool/owner/tool_name, from that we
    get the tool that is being requested and it's owner. If the requester is
    a member of the shed that the tool is in or if the tool is at home, the requester
    will be sent to a page where they can select dates to reserve it. Otherwise
    they will be sent back to the page they came from.
    """
    user = request.user
    url = request.path
    url = url.replace('/BorrowTool/', '')
    owner_and_tool = url.split("/")
    owner_name = owner_and_tool[0]
    tool_name = owner_and_tool[1]
    all_users = Person.objects.all()
    for user in all_users:
        if user.username == owner_name:
            owner = user
    for t in owner.registered_tools.all():
        if t.name == tool_name:
            tool = t
    shed = None
    tool_at_home = True
    if tool.in_a_shed:
        shed = tool.shed
        tool_at_home = False
    member_of_shed = False
    for s in user.sheds.all():
        if(s == shed):
            member_of_shed = True
    if(member_of_shed or tool_at_home):
        t = loader.get_template('BorrowTool.html')
        c = RequestContext(
             request, {
             'user' : user,
             'owner': owner,
             'tool' : tool,
             'is_member' : member_of_shed,
             })
        return HttpResponse(t.render(c))
    else:
        return HttpResponse('Request denied.  The tool you are requesting is in a shed that you are not a member of.')

@login_required(login_url='/Login')
def BorrowToolRequest(request):
    """
    This is where the request will be processed for borrowing a tool.
    This is called when a user submits a borrow form from ToolRequest.html.
    """
    user = request.user
    tool_name = request.POST.get('tool')
    owner_name = request.POST.get('owner')
    start_date = request.POST.get('start_date')
    end_date = request.POST.get('end_date')
    message = request.POST.get('message')

    owner = None
    tool = None

    for person in Person.objects.all():
        if person.username == owner_name:
            owner = person
    for t in owner.registered_tools.all():
        if t.name == tool_name:
            tool = t

    if not tool.is_valid(start_date,end_date):
        return HttpResponse('Invalid start and end dates entered. Please hit back and try again.')

    #Check if requester is a member of the shed if the tool is in a shed.
    if tool.in_a_shed:
        is_member = False
        for s in user.sheds.all():
            if(s == tool.shed):
                is_member = True

        if not is_member:
            return HttpResponseRedirect('Request denied.  The tool you are requesting is in a shed that you are not a member of.')
        elif tool.no_conflict(start_date, end_date):
            tool.borrower=user
            tool.save()
            user.borrowed_tools.add(tool)
            message = "You have successfully requested " + tool.name + " for the dates of " + start_date + " to " + end_date
            note = Notification.create(user, message, 1)
            return HttpResponseRedirect('/Home/')
        elif not tool.no_conflict(start_date, end_date):
            return HttpResponse('Request denied.  The tool you are requesting is already reserved during that time frame.')
    else:
        if tool.no_conflict(start_date, end_date):
            req = ToolRequest.create(user, tool.owner, tool, start_date, end_date, message)
            message = "You have sent " + tool.owner.first_name + " " + tool.owner.last_name + " (" + tool.owner.username + ") a request to borrow " + tool.name + " from " + start_date + " to " + end_date
            note = Notification.create(user, message, 1)
            return HttpResponseRedirect('/Home/')
        else:
            return HttpResponse('Request denied.  The tool you are requesting is already reserved during that time frame.')
            #redirect user back to BorrowRequest, invalid dates.


    #TODO: process borrow request.
    # If the tool is being loaned from home, send the request to owner.
    # It should still check blackout/already reserved dates.
    # If the tool is being loaned from a shed, process and automatically
    # approve if requester is member of shed.
@login_required(login_url='/Login')
def BorrowToolRequestAccept(request):
    """
    This view is called when an owner accepts a user's request to borrow
    a tool. The url should be in the form: /BorrowToolRequestAccept/ToolRequest_id
    """
    #message = request.POST['message']
    user = request.user
    url = request.path
    id = url.replace("/BorrowToolRequestAccept/", '')
    all_requests = user.tool_requests.all()
    for t_r in all_requests:
        if t_r.id == int(id):
            req = t_r
    req.accept('')
    message_to_requester = "Your request to borrow " + req.owner.first_name + " " + req.owner.last_name + "'s tool: \"" + req.tool.name + "\" has been accepted!"
    if req.response_message != "":
        message_to_requester += " Here is a message from " + req.owner.first_name + ": " + req.response_message
    accept_notification = Notification.create(req.borrower, message_to_requester, 1)
    req.delete()
    return HttpResponseRedirect('/Home/')

@login_required(login_url='/Login')
def BorrowToolRequestDecline(request):
    """
    This view is called when an owner declines a user's request to borrow
    a tool. The url should be in the form: /BorrowToolRequestDecline/ToolRequest_id
    """
    #message = request.POST['message']
    url = request.path
    req_id = url.replace("/BorrowToolRequestDecline/", '')
    all_requests = ToolRequest.objects.all()

    for t_r in all_requests:
        if t_r.id == int(req_id):
            req = t_r
    req.decline('')
    message_to_requester = "I'm sorry, your request to borrow " + req.owner.first_name + " " + req.owner.last_name + "'s tool: \"" + req.tool.name + "\" has been declined"
    if req.response_message != "":
        message_to_requester += " Here is a message from " + req.owner.first_name + ": " + req.response_message
    decline_notification = Notification.create(req.borrower, message_to_requester, 2)
    req.delete()
    return HttpResponseRedirect('/Home/')

@login_required(login_url='/Login')
def DeleteTool(request):
    user = request.user
    url = request.path
    url = url.replace('/DeleteTool/', '')
    tool=list(user.registered_tools.filter(name=url))
    tool=tool[0]
    message = "You have deleted Tool" + tool.name
    tool.delete()
    Notification.create(user,message, 3)
    return HttpResponseRedirect("/Tools/")

@login_required(login_url='/Login')
def DeleteShed(request):
    user=request.user
    url = request.path
    url = url.replace('/DeleteShed/', '')
    shed=Shed.objects.all().filter(name=url)
    shed=shed[0]
    message = "You have deleted Shed" + shed.name
    shed.delete()
    Notification.create(user,message, 3)
    return HttpResponseRedirect("/Sheds/")

@login_required(login_url='/Login/')
@csrf_protect
def EditInfo(request):
    """
    This view is where the user can edit their personal information they had
    previously supplied except their username. The form is similar to the
    registration form except the form is already populated with their current
    information. THe one exception is the password field, however if new information
    is not supplied the password will remain the same.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    user = request.user
    t = loader.get_template('edit_info.html')
    c = RequestContext(
             request, {
             'username': user.username,
             'password' : user.password,
             'email': user.email,
             'first_name': user.first_name,
             'last_name': user.last_name,
             'street_address': user.address.street_address,
             'city': user.address.city,
             'state':user.address.state,
             'zip':user.address.zip,
             'phone_number1': user.phone_number[:3],
             'phone_number2' : user.phone_number[3:6],
             'phone_number3' : user.phone_number[6:],
             'question1':user.question1,
             'answer1':user.answer1,
             'question2':user.question2,
             'answer2':user.answer2,
             })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login/')
@csrf_protect
def EditInfoSave(request):
    """
    This is a middleman view for editing information
    The contents of the edit form are passed into this view and changes are
    made to the users profile accordingly.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    num1=request.POST['phone_number1']
    num2=request.POST['phone_number2']
    num3=request.POST['phone_number3']
    phone_number=num1+num2+num3

    user=request.user
    user.first_name=request.POST['first_name']
    user.last_name=request.POST['last_name']
    user.question1=request.POST['question1']
    user.answer1=request.POST['answer1']
    user.question2=request.POST['question2']
    user.answer2=request.POST['answer2']
    if (request.POST.get('password','')!=''):
        user.set_password(request.POST['password'])
    user.email=request.POST['email']
    user.phone_number=phone_number
    user.UpdateAddress(request.POST['street_address'], request.POST['city'], request.POST['state'], request.POST['zip_code'])
    user.save()
    return HttpResponseRedirect("/Personal_Information/")

@login_required(login_url='/Login')
def EditShed(request):

    user = request.user
    url = request.path
    url = url.replace('/EditShed/', '')
    shed = None
    if user.sheds is not None:
        shed_list = user.sheds.all()
        for entry in shed_list:
            if entry.name == url:
                shed = entry

    #T
    if shed is None:
        return(HttpResponse('Sorry, that is not one of your sheds.'))

    t = loader.get_template('EditShed.html')
    c = RequestContext(request,
                       {
                        'user' : user,
                        'shed' : shed,
                        })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login')
def EditShedSave(request):
    user = request.user
    url = request.path
    url = url.replace('/EditShedSave/', '')
    opshed = None
    if user.sheds is not None:
        all_entries=user.sheds.all()
        for entry in all_entries:
            if entry.name == url:
                opshed = entry

    description = request.POST['description']
    name = request.POST['name']

    if not request.POST.get('chbox', False):
        street_address = request.POST['street_address']
        city = request.POST['city']
        state = request.POST['state']
        zip_code = request.POST['zip_code']
        shed_list = list(Shed.objects.all())
        for shed in shed_list:
            if (shed.address.street_address == street_address and shed.address.city == city and shed.address.state == state and shed.address.zip == zip_code) and shed != opshed:
                t = loader.get_template('EditShed.html')
                c = RequestContext(request,{
                                'user' : user,
                                'street_address': street_address,
                                'city': city,
                                'zip': zip_code,
                                'state': state,
                                'shed_name': name,
                                'shed_description' : description,
                                'error': 1,
                               })
                return HttpResponse(t.render(c))

    if not request.POST.get('chbox', False):
        opshed.address.street_address = street_address
        opshed.address.city=city
        opshed.address.state=state
        opshed.address.zip=zip_code
        opshed.address.save()
        opshed.address.recalc()
    else:
        for shed in shed_list:
            if (shed.address.street_address == user.address.street_address and shed.address.city == user.address.city and shed.address.state == user.address.state and shed.address.zip == user.address.zip_code) and shed != opshed:
                t = loader.get_template('EditShed.html')
                c = RequestContext(request,{
                                'user' : user,
                                'street_address': street_address,
                                'city': city,
                                'zip': zip_code,
                                'state': state,
                                'shed_name': name,
                                'shed_description' : description,
                                'error': 1,
                               })
                return HttpResponse(t.render(c))
        shed.address = user.address
    if request.POST['privacy']=='public':
        opshed.private=False
    else:
        opshed.private=True

    opshed.description = description
    opshed.name= name

    shed.save()
    return HttpResponseRedirect('/ShedInfo/'+shed.name)

@login_required(login_url='/Login')
def EditToolInfo(request):
    user = request.user
    url = request.path
    url = url.replace('/EditToolInfo/', '')
    shed_list = []
    if user.sheds is not None:
        shed_list = user.sheds.all()
    tool = None

    if user.registered_tools is not None:
        all_entries=user.registered_tools.all()
        for entry in all_entries:
            if entry.name == url:
                tool = entry
    options = ["Home", "Shed"]
    if tool.pickup_arrangements in options:
        options.remove(tool.pickup_arrangements)

    t = loader.get_template('EditToolInfo.html')
    c = RequestContext(request,
                       {
                        'pickup_options' : options,
                        'shed_list' : shed_list,
                        'tool' : tool,
                        'first_name' : user.first_name,
                        'last_name' : user.last_name,
                        })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login')
def EditToolInfoSave(request):
    user = request.user
    url = request.path
    url = url.replace('/EditToolInfoSave/', '')
    tool = None
    if user.registered_tools is not None:
        all_entries=user.registered_tools.all()
        for entry in all_entries:
            if entry.name == url:
                tool = entry
    pre_in_shed = tool.in_a_shed
    pre_shed = tool.shed
    tool.name= request.POST['name']
    tool.description = request.POST['description']
    tool.category = request.POST['category']
    tool.pickup_arrangements = request.POST['pickup_arrangements']
    tool.special_instructions = request.POST['special_instructions']
    shed=None
    tool.save()
    shed_list = []
    if user.sheds is not None:
        shed_list = user.sheds.all()
    if request.POST['pickup_arrangements'] == "Shed":
        for s in shed_list:
            if s.name == request.POST['shed']:
                shed = s
                """SHED SPECIFIED IN FORM"""
    if not pre_in_shed and pre_shed is None:
        if shed is not None:
            tool.add_to_shed(shed)
    else:
        if shed is not None and shed != pre_shed:
            tool.remove_from_shed()
            tool.add_to_shed(shed)
        elif shed is None:
            tool.remove_from_shed()
            tool.address=user.address
            tool.save()
    return HttpResponseRedirect('/ToolInfo/'+tool.name+'/'+user.username)

@login_required(login_url='/Login')
def History(request):
    user = request.user
    notification_list = user.notifications.all()
    t = loader.get_template("History.html") #CHANGE THIS
    c = RequestContext(
              request, {
             'notification_list' : notification_list
             })
    return HttpResponse(t.render(c))

def Home(request):
    """
    The home view is unique to every user. From here the user can see their
    notifications, a selection of their tools and sheds, and through the navbar
    can add tools, create sheds, join sheds and search tools.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    user = request.user
    t = loader.get_template('Home.html')
    if isinstance(request.user, AnonymousUser):
        return Main(request)
    tool_list = []
    shed_list = []
    notification_list = []
    shed_requests = []
    tool_requests = []
    if user.registered_tools is not None:
        tool_list = list(user.registered_tools.all())
        tool_list = random.sample(tool_list, len(tool_list))
        tool_list = tool_list[0:4]
    if user.sheds is not None:
        shed_list = list(user.sheds.all())
        shed_list = random.sample(shed_list, len(shed_list))
        shed_list = shed_list[0:4]
    if user.notifications is not None:
        notification_list = list(user.notifications.all().order_by('-timestamp'))
        notification_list = notification_list[0:8]
    if user.shed_requests is not None:
        shed_requests = user.shed_requests.all()
    if user.tool_requests is not None:
        tool_requests = user.tool_requests.all()

    c = RequestContext(
              request, {
             'user' : user,
             'first_name': user.first_name,
             'last_name': user.last_name,
             'tools' : tool_list,
             'shed_list' : shed_list,
             'notifications' : notification_list,
             'shed_requests' : shed_requests,
             'tool_requests' : tool_requests,
             })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login/')
@csrf_protect
def JoinShedRequest(request):
    """
    This view is called when a user requests to join a shed. The url should be
    in the form /JoinShedRequest/coordinator_name/shed_name
    """
    user = request.user
    message=request.POST['message']
    url = request.path
    url = url.replace('/JoinShedRequest/', '')
    coordinator_and_shed = url.split("/")
    coordinator_name = coordinator_and_shed[0]
    shed_name = coordinator_and_shed[1]
    all_users = Person.objects.all()
    for u in all_users:
        if u.username == coordinator_name:
            coordinator = u
    for s in coordinator.coordinator_of.all():
        if s.name == shed_name:
            shed = s
    shed_request_obj = ShedRequest.create(user, shed, message)
    message = "Your request to join " + shed_name + " has been sent."
    sent_notification = Notification.create(user, message, 1)
    return HttpResponseRedirect('/Home/')

@login_required(login_url='/Login')
def JoinShedRequestAccept(request):
    """
    This view is called when a shed coordinator accepts a user's
    request to join a shed. The url should be in the form:
    /JoinShedRequestAccept/ShedRequest_id
    """
    #message = request.POST['message']
    url = request.path
    id = url.replace("/JoinShedRequestAccept/", '')
    shed_request = None
    all_requests = ShedRequest.objects.all()
    for s_r in all_requests:
        if s_r.id == int(id):
            shed_request = s_r

    if shed_request is None:
        return HttpResponse("You're not supposed to be here!")
    shed_request.accept("")
    message_to_requester = "Your request to join " + shed_request.shed.coordinator.first_name + " " + shed_request.shed.coordinator.last_name + "'s shed: \"" + shed_request.shed.name + "\" has been accepted!"
    if shed_request.response_message != "":
        message_to_requester += "\nHere is a message from the coordinator: " + shed_request.response_message
    accept_notification = Notification.create(shed_request.requester, message_to_requester, 1)
    message_to_coordinator = "You have approved " + shed_request.requester.first_name + " " + shed_request.requester.last_name + "'s (" + shed_request.requester.username + ")" + " request to join " + shed_request.shed.name
    accept_notification_coordinator = Notification.create(shed_request.shed.coordinator, message_to_coordinator, 1)
    shed_request.delete()
    return HttpResponseRedirect("/Home/")

@login_required(login_url='/Login')
def JoinShedRequestDecline(request):
    """
    This view is called when a shed coordinator declines a user's
    request to join a shed. The url should be in the form:
    /JoinShedRequestDecline/ShedRequest_id
    """
    #message = request.POST['message']
    url = request.path
    id = url.replace("/JoinShedRequestDecline/", '')
    all_requests = ShedRequest.objects.all()
    for s_r in all_requests:
        if s_r.id == int(id):
            req = s_r
    req.decline('')
    message_to_requester = "I'm sorry, your request to join " + req.shed.coordinator.first_name + " " + req.shed.coordinator.last_name + "'s shed: \"" + req.shed.name + "\" has been rejected"
    if req.response_message != "":
        message_to_requester += "\nHere is a message from the coordinator: " + req.response_message
    decline_notification = Notification.create(req.requester, message_to_requester, 2)

    message_to_coordinator = "You have rejected " + req.requester.first_name + " " + req.requester.last_name + "'s (" + req.requester.username + ")" + " request to join " + req.shed.name
    accept_notification_coordinator = Notification.create(req.shed.coordinator, message_to_coordinator, 2)

    req.delete()
    return HttpResponseRedirect("/Home/")

def Login(request):
    """
    Upon clicking the login button on the main page the user is directed to this
    view to enter this account information to be logged into the site.
    """
    url = request.path
    url = url.replace('/Login/', '')
    if url == "Error/":
        t = loader.get_template('Login.html')
        c = RequestContext(
              request, {
             'errorcode': 1,
             })
        return HttpResponse(t.render(c))
    else:
        return render_to_response('login.html',context_instance=RequestContext(request))

def LoginRequest(request):
    """
    This is a middleman view for the Login process. After the form is submitted in
    the login view the user is redirected here. The supplied information is
    authenticated using the built in django authentication system. If the user
    is not in the system, a page is loaded where they are told their information
    was not correct and are then redirected to the login page. If their credentials
    are valid they are logged into the system and are redirected to their home page.
    """
    Username=request.POST['username']
    Password=request.POST['password']
    user = authenticate(username=Username, password=Password)
    if user is not None:
                LOGIN(request, user)
                return HttpResponseRedirect("/Home/")
    else:
        return HttpResponseRedirect("/Login/Error/")

def Logout(request):
    """
    Upon clicking the logout button on the homebar the user is sent to this view
    where the user's session is ended with the server and is redirected to the
    main page.
    """
    LOGOUT(request)
    return render_to_response('Main.html',context_instance=RequestContext(request))

def Main(request):
    """
    The main view for the website. This is the view that is loaded upon
    trying to access the root of the website. If the site detects that the user
    is already logged in it will redirect the user to their Home page (Home). If
    they are not they are asked to sign in or create an account.
    """
    try:
        if request.user.id is not None:
            return  HttpResponseRedirect("/Home/")
        else:
            return render_to_response('Main.html')
    except (AttributeError, OperationalError):
        return render_to_response('Main.html')

@login_required(login_url='/Login')
def Notifications(request):
    user = request.user
    t = loader.get_template('Notifications.html')
    c = RequestContext( request, {
            'user': user,
            'notifications' : user.notifications.all().reverse(),
            })
    return HttpResponse(t.render(c))


@login_required(login_url='/Login/')
@csrf_protect
def PersonalInfo(request):
    """
    This view is where the user can view their current account information and
    can edit it by either clicking a button at the bottom of the page or selecting
    edit information from the navbar on eny page. The information shown on this
    page is prepopulated by the view then passed into the html code.
    This view is login protected so if a unauthenticated viewer tries to access
    this view directly through the URL it will redirect them to login and once they
    have been authenticated they will return to this view.
    """
    user = request.user
    t = loader.get_template('personal_info.html')
    c = RequestContext(
              request, {
             'user' : user,
             'username': user.username,
             'email': user.email,
             'first_name': user.first_name,
             'last_name': user.last_name,
             'street_address': user.address.street_address,
             'city': user.address.city,
             'state':user.address.state,
             'zip':user.address.zip,
             'phone_number1': user.phone_number[:3],
             'phone_number2' : user.phone_number[3:6],
             'phone_number3' : user.phone_number[6:],
             })
    return HttpResponse(t.render(c))

def ForgotPassword(request):
    return render_to_response('ForgotPassword.html',context_instance=RequestContext(request))

def SecurityQuestions(request):
    email = request.POST['email']
    emlcheck = Person.objects.all().filter(email=email)
    if emlcheck.exists():
        for entry in emlcheck:
            user = entry
            username = entry.username
            question1 = user.question1
            question2 = user.question2
            answer1 = user.answer1
            answer2 = user.answer2
        t = loader.get_template('SecurityQuestions.html')
        c = RequestContext(request,{
                        'error' : False,
                        'username' : username,
                        'question1' : question1,
                        'question2' : question2,
                        'answer1' : answer1,
                        'answer2' : answer2,
                       })
        return HttpResponse(t.render(c))
    else:
        error = True
        t = loader.get_template('ForgotPassword.html')
        c = RequestContext(request,{
                        'error' : error
                       })
        return HttpResponse(t.render(c))

def SecurityCheck(request):
    url = request.path
    username = url.replace('/SecurityCheck/', '')
    usrCheck = Person.objects.all().filter(username=username)
    for u in usrCheck:
        user = u
    if(request.POST['answer1'].lower() == user.answer1.lower() and request.POST['answer2'].lower() == user.answer2.lower()):
        t = loader.get_template('NewPassword.html')
        c = RequestContext(
              request, {
             'username' : username,
             })
        return HttpResponse(t.render(c))
    else:
        t = loader.get_template('SecurityQuestions.html')
        c = RequestContext(request,{
                        'error' : True,
                        'username' : username,
                        'question1' : user.question1,
                        'question2' : user.question2,
                        'answer1' : user.answer1,
                        'answer2' : user.answer2,
                       })
        return HttpResponse(t.render(c))

def ChangePassword(request):
    url = request.path
    uname = url.replace('/ChangePassword/', '')
    password = request.POST['password']
    usrCheck = Person.objects.all().filter(username=uname)
    for u in usrCheck:
        user = u
    user.set_password(password)
    user.save()
    return render_to_response('Login.html',context_instance=RequestContext(request))

def Register(request):
    """
    Upon clicking the register button on the main page the user will be sent to
    this view. This is where the user enters their information to create an account.
    """
    return render_to_response('register.html',context_instance=RequestContext(request))

def RegistrationRequest(request):
    """
    This is a middleman view for the registration process. Upon filling out the
    form in the register view the information is then sent here. If either the
    username or email supplied already exists in the system the user is notified
    that the account already exists and is redirected to the login view. If the
    information is unique, an account is created for the new user and said user
    is logged into the system automatically.
    """
    num1=request.POST['phone_number1']
    num2=request.POST['phone_number2']
    num3=request.POST['phone_number3']
    phone_number=num1+num2+num3

    usrcheck = Person.objects.all().filter(username=request.POST['username'])
    emlcheck = Person.objects.all().filter(email=request.POST['email'])
    userError = False
    emailError = False
    if  usrcheck.exists():
        userError = True
        t = loader.get_template('Register.html')
        c = RequestContext(request,{
                        'error' : userError
                       })
        return HttpResponse(t.render(c))
    elif emlcheck.exists():
        emailError = True
        t = loader.get_template('Login.html')
        c = RequestContext(request,{
                        'error' : emailError
                       })
        return HttpResponse(t.render(c))
    Person.objects.create_user(
                           request.POST['username'],
                           request.POST['email'],
                           request.POST['password'],
                           request.POST['first_name'],
                           request.POST['last_name'],
                           request.POST['street_address'],
                           request.POST['city'],
                           request.POST['state'],
                           request.POST['zip_code'],
                           phone_number,
                           request.POST['question1'],
                           request.POST['answer1'],
                           request.POST['question2'],
                           request.POST['answer2'])
    return LoginRequest(request)

@login_required(login_url='/Login/')
def RegisterShed(request):
    """
    This is the view used by the user to create a new shed. THe users address is
    used as the default shed location.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    user = request.user
    t = loader.get_template('RegisterShed.html')
    c = RequestContext(request,{
                        'user': user,
                        'first_name': user.first_name,
                        'last_name' : user.last_name,
                       })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login/')
def RegisterShedRequest(request):
    """
    This is the middleman view for creating a shed. All the information supplied
    in the forms is sent here and the shed is created with the proper attributes
    After creation the creator is automatically added to the shed and set as
    the coordinator of the shed. After creation the user is redirected to the
    information page for that shed.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    user = request.user
    description = request.POST['description']
    name = request.POST['name']

    if not request.POST.get('chbox', False):
        street_address = request.POST['street_address']
        city = request.POST['city']
        state = request.POST['state']
        zip_code = request.POST['zip_code']
        shed_list = list(Shed.objects.all())
        for shed in shed_list:
            if (shed.address.street_address == street_address and shed.address.city == city and shed.address.state == state and shed.address.zip == zip_code):
                t = loader.get_template('RegisterShed.html')
                c = RequestContext(request,{
                                'user' : user,
                                'street_address': street_address,
                                'city': city,
                                'zip': zip_code,
                                'state': state,
                                'shed_name': name,
                                'shed_description' : description,
                                'error': 1,
                               })
                return HttpResponse(t.render(c))
        address = Address.create(street_address, city, state, zip_code)
    else:
        address = user.address

    if request.POST['privacy']=='public':
        private=False
    else:
        private=True

    try:
        shed = Shed.create(name, address, user, description, private)
    except IntegrityError:
            t = loader.get_template('RegisterShed.html')
            c = RequestContext(request,{
                                'user' : user,
                                'first_name': user.first_name,
                                'last_name' : user.last_name,
                                'error': 1,
                               })
            return HttpResponse(t.render(c))
    return HttpResponseRedirect("/Sheds/")


@login_required(login_url='/Login/')
def Sheds(request):
    """
    The information page for any given shed. The shed information is pulled from
    the server and the page is populated with its information.
    This view is login protected as to prevent any unauthenticated users from
    accessing this page through URL.
    """
    user = request.user
    member_list = []
    coordinator_list=[]
    if user.coordinator_of is not None:
        coordinator_list = list(user.coordinator_of.all())
    if user.sheds is not None:
        memberquery_list = user.sheds.all()
    #making the QuerySets into lists to modify data
    for shed in memberquery_list:
        if shed not in coordinator_list:
            member_list.append(shed)
    t = loader.get_template('Sheds.html')
    c = RequestContext(
                       request,{
                        'member_list' : member_list,
                        'coordinator_list' : coordinator_list,
                        'user' : user,
                       })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login')
def ShedSearch(request):
    user=request.user
    try:
        distance=request.POST['distance']
    except MultiValueDictKeyError :
        distance = 5;
    ShedListQuery = Shed.objects.all()
    UserSheds = user.sheds.all()
    ShedList=[]
    MemberArray= list(user.sheds.all())
    ShedList_filtered=[]
    for shed in ShedListQuery:
        if Address.Distance('',shed,user)< float(distance):
            ShedList.append(shed)
    for shed in ShedList:
        if not (shed.private == True and shed not in MemberArray):
            ShedList_filtered.append(shed)
    t = loader.get_template('ShedSearch.html')
    c = RequestContext(request,
                       {
                        'user': request.user,
                        'distance': distance,
                        'ShedList' : ShedList_filtered,
                        'UserSheds':UserSheds,
                        })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login')
def ShedInfo(request):
    user = request.user
    url = request.path
    url = url.replace('/ShedInfo/', '')
    shed = None
    shed_list = Shed.objects.all()
    for entry in shed_list:
        if entry.name == url:
            shed = entry
    if shed is None:
        return HttpResponse("This shed does not exist.  <a href='/Home/'>Get me out of here!</a>")

    member_of_shed = False
    for s in user.sheds.all():
        if(s == shed):
            member_of_shed = True


    isCoordinator = (shed.coordinator == user)
    t = loader.get_template('ShedInfo.html')
    c = RequestContext(request,
                       {
                        'user' : user,
                        'shed' : shed,
                        'isCoord' : isCoordinator,
                        'is_member' : member_of_shed,
                        })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login')
def ToolConfirmationAccept(request):
    user = request.user
    url = request.path
    id = url.replace('/ToolConfirmationAccept/', '')
    all_requests = ExtensionRequest.objects.all()
    for c_r in all_requests:
        if c_r.id == int(id):
            request = c_r
    request.accept()

@login_required(login_url='/Login')
def ToolConfirmationDecline(request):
    user = request.user
    url = request.path
    id = url.replace('/ToolConfirmationDecline/', '')
    all_requests = ExtensionRequest.objects.all()
    for c_r in all_requests:
        if c_r.id == int(id):
            request = c_r
    request.decline()

@login_required(login_url='/Login')
def ToolExtensionAccept(request):
    user = request.user
    url = request.path
    id = url.replace('/ToolExtensionAccept/', '')
    all_requests = ExtensionRequest.objects.all()
    for e_r in all_requests:
        if e_r.id == int(id):
            request = e_r
    request.accept()

@login_required(login_url='/Login')
def ToolExtensionDecline(request):
    user = request.user
    url = request.path
    id = url.replace('/ToolExtensionDecline/', '')
    all_requests = ExtensionRequest.objects.all()
    for e_r in all_requests:
        if e_r.id == int(id):
            request = e_r
    request.decline()

@login_required(login_url='/Login')
def ToolSearch(request):
    user=request.user
    try:
        distance=request.POST['distance']
    except MultiValueDictKeyError :
        distance = 10;
    try:
        SearchQuery=request.POST['category']
    except MultiValueDictKeyError :
        SearchQuery = '';

    #initilizing nesesary objects and all relevent database queries
    ToolListQuery = Tool.objects.all()
    ToolList_distancefilter=[]
    ToolList=[]
    ToolList_final=[]
    user_sheds = list(user.sheds.all())

    #filtering tools by distance
    for tool in ToolListQuery:
        if Address.Distance('',tool,user)<float(distance):
            ToolList_distancefilter.append(tool)
    #filtering out tools in private sheds that the user is not a part of
    for tool in ToolList_distancefilter:
        if not ( tool.in_a_shed is True and tool.shed not in user_sheds and tool.shed.private is True):
            ToolList.append(tool)

    if SearchQuery is not '':
        for tool in ToolList:
            if SearchQuery== tool.category:
                ToolList_final.append(tool)
    else:
        ToolList_final=ToolList

    t = loader.get_template('ToolSearch.html')
    c = RequestContext(request,
                       {
                        'user': request.user,
                        'ToolList' : ToolList_final,
                        'distance':distance,
                        'query': SearchQuery,
                        })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login')
def ToolInfo(request):
    user = request.user
    url = request.path
    url = url.split('/',)
    tool_name = url[2]
    tool_owner= url[3]
    tool = None
    all_entries=Tool.objects.all()
    for entry in all_entries:
        if entry.name == tool_name and entry.owner.username==tool_owner:
            tool = entry
    if tool != None and tool.in_a_shed:
        shed_name = tool.shed.name
    else:
        shed_name = "None"

    t = loader.get_template('ToolInfo.html')
    c = RequestContext(request,
                       {
                        'shed' : shed_name,
                        'tool' : tool,
                        'user' : user
                        })
    return HttpResponse(t.render(c))

@login_required(login_url='/Login/')
def Tools(request):
    user = request.user
    t = loader.get_template('Tools.html')
    c = RequestContext(request,
                       {
                        'user' : user,
                        })
    return HttpResponse(t.render(c))