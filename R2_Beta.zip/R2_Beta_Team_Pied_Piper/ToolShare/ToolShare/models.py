"""
Models.py
A File containing all of the back end models for the ToolShare application
Contains Models for the Address class, User Class, Tool Class and Shed Class
Written by Team Pied Piper
"""

"Import Section for all Models"
from django.db import models
from Python_Geocoder import google
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser
from django.db.models.fields.related import OneToOneField
from datetime import date, datetime
from math import radians, cos, sin, asin, sqrt
from decimal import *

class Address(models.Model):
    """
    Address Class
    Used by and linked to the User Class and Shed Class
    This class is used to store all the address elements of a specific user or shed.
    This class relies on the Python_Geocoder library to calculate the user's
    or shed's latitude and longatude from their entered information using the
    Google API servers.
    This class stores all values in CharFields.
    """

    """Class Variables and Values"""
    street_address = models.CharField(max_length = 50)
    city = models.CharField(max_length = 50)
    state = models.CharField(max_length = 2)
    zip = models.CharField(max_length = 5)
    lat = models.CharField(max_length = 50)
    long = models.CharField(max_length = 50)

    @classmethod
    def create(self, street, city, state, zip_code):
        """
        Constructor Method for the Address Class
        Takes in the given parameters from the ToolShare Constructor or the
        Shed Constructor and finds the coordinates of the user or shed. It then
        returns the newly created Address object to the caller.
        """
        client = google.GoogleGeocoderClient(False)
        location = street + " " + city + " " + state
        coord = client.geocode(location)
        coords = coord.get_location()
        new_address = Address()
        new_address.street_address = street
        new_address.city = city
        new_address.state = state
        new_address.zip = zip_code
        new_address.lat = coords[0]
        new_address.long = coords[1]
        new_address.save()
        return new_address

    def ToString(self):
        string = self.street_address+', '+self.city+', '+self.state+', '+self.zip
        return string

    def Distance(self, object1, object2):
        #parsing the object input into their seperate lat/long
        long1=Decimal(object1.address.long)
        lat1=Decimal(object1.address.lat)
        long2=Decimal(object2.address.long)
        lat2=Decimal(object2.address.lat)
        # convert decimal degrees to radians
        long1, lat1, long2, lat2 = map(radians, [long1, lat1, long2, lat2])

        # Haversine formula
        dlon = long2 - long1
        dlat = lat2 - lat1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * asin(sqrt(a))

        # 6367 km is the radius of the Earth
        KiloDistance = 6367 * c
        #converting to miles
        MilesDistance = KiloDistance * 0.621371
        return MilesDistance

    def recalc(self):
        client = google.GoogleGeocoderClient(False)
        location = self.street_address + " " + self.city + " " + self.state
        coord = client.geocode(location)
        coords = coord.get_location()
        self.lat = coords[0]
        self.long = coords[1]
        return True


class Notification(models.Model):
    """
    Notification class is for general notifications sent to the user.
    The following would be examples of notification:
        -A requested Tool is no longer available.
        -A shed has been deleted (notifications sent to members)

    Urgency will be defined as followed:
        -1 = Good
        -2 = Warning
        -3 = Danger
    """
    message = models.TextField(max_length=100)
    recipient = models.ForeignKey('Person', related_name='+')
    urgency = models.IntegerField(default = 0)
    timestamp = models.DateTimeField()

    is_extend_date_request = models.BooleanField(False)


    @classmethod
    def create(self, recipient, message, urgency):
        new_notification = Notification()
        new_notification.message = message
        new_notification.recipient = recipient
        new_notification.urgency = urgency
        new_notification.timestamp = datetime.now()
        new_notification.is_extend_date_request=False
        new_notification.save()
        recipient.notifications.add(new_notification)
        return new_notification


    def delete(self):
        self.delete()

class ToolShare(BaseUserManager):
    """
    Manager Class for the Person-User Class. Used to override the default
    Django User class. This allows for extra information to be stored such as
    the users address, their tools they registered and the sheds they are a part
    of. Functions exactly like the default user class in every other way.
    Authentication is done based on the username and password and no two users
    can have the same username or email address.
    """
    def create_user(self, username, email, password, first, last, street, city,
                                                state, zip_code, phone_number, question1, answer1, question2, answer2):
        """
        Constructor for an instance of the Person Class. Creates a person object
        using the information passed in by the calling method and creates an
        entry in the database for the User. All data is verified before it is
        passed into this method by either the templet or the view. After the
        user is created and added to the database the user object is returned to
        the calling method.
        """
        user = self.model(
            username = username,
            email=ToolShare.normalize_email(email),
            first_name = first,
            last_name = last,
            phone_number = phone_number,
            address = Address.create(street, city, state, zip_code),
            question1 = question1,
            answer1 = answer1,
            question2 = question2,
            answer2 = answer2,
            )
        user.set_password(password)
        user.save(using=self._db)
        return user

class Person(AbstractBaseUser):
    """
    Person Class, this is a class for each registered user
    This class is created by and managed by the ToolShare class
    This is where all the users personal information, registered tools and
    sheds they are a part of are tracked.
    When referencing a user though request.user this is where the call is
    directed to.
    When searching the database for users this class/object is the entry to
    search for and whos attributes to consider when filtering
    Methods do not contain .save() calls and as such .save() should be used in
    the calling method.
    """
    class Meta:
        app_label = 'ToolShare'
        abstract = False
    email = models.EmailField(
                                  verbose_name='email address',
                                  max_length=255,
                                  unique=True,
                                  )
    username = models.TextField(unique = True, max_length = 50)
    first_name = models.TextField(max_length = 50)
    last_name = models.TextField(max_length = 50)
    num_strikes = models.IntegerField(default = 0)
    phone_number = models.CharField(max_length = 10)
    objects = ToolShare()
    borrowed_tools = models.ManyToManyField('Tool', null = True, blank = True, related_name ="n")

    coordinator_of = models.ManyToManyField('Shed', related_name='+', null=True, blank=True)
    address = models.ForeignKey('Address', unique = True)
    sheds = models.ManyToManyField('Shed', null = True, blank = True)
    registered_tools = models.ManyToManyField('Tool',null=True, blank=True)
    shed_requests = models.ManyToManyField('ShedRequest', null = True, blank = True)
    tool_requests = models.ManyToManyField('ToolRequest', null = True, blank = True)
    extension_requests = models.ManyToManyField('ExtensionRequest', null = True, blank = True)
    confirmation_requests = models.ManyToManyField('ConfirmationRequest', null = True, blank = True)
    notifications = models.ManyToManyField('Notification', null = True, blank = True, related_name="+")
    question1 = models.TextField(max_length = 50)
    question2 = models.TextField(max_length = 50)
    answer1 = models.TextField(max_length = 50)
    answer2 = models.TextField(max_length = 50)
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email, username, first_name, last_name']

    def coordinate_shed(self, shed):
        self.coordinator_of.add(shed)
        self.save()

    def add_strikes(self, num):
        self.num_strikes += num
        self.save()

    def register_tool(self, tool):
        self.registered_tools.add(tool)
        self.save()

    def remove_tool(self, tool):
        for t in self.registered_tools:
            if t == tool:
                self.registered_tools.remove(t)
        self.save()

    def join_shed(self, shed):
        self.sheds.add(shed)
        self.save()

    def leave_shed(self, shed):
        for s in self.sheds:
            if(s == shed):
                self.sheds.remove(shed)
        self.save()

    def new_tool_request(self, request):
        self.tool_requests.add(request)
        self.save()

    def new_shed_request(self, request):
        self.shed_requests.add(request)
        self.save()

    def UpdateAddress(self, address, city, state, zip):
        self.address.street_address=address
        self.address.city=city
        self.address.state=state
        self.address.zip=zip
        self.address.recalc()
        self.address.save()
        self.save()

    def add_notification(self, note):
        self.notifications.add(note)
        self.save()

class Shed(models.Model):
    """
    Shed class, a class that models any given shed in the ToolShare system
    This object contains the address of the shed(Address Class), the person
    (Person Class) who is the designated shed coordinator, the name of the shed,
    a short description of the shed, a boolean to toggle privacy settings and
    arrays for the members of the shed and the tools it contains
    Private shed VS Public shed
    Private shed-coordinator must approve a users request to join a shed, the
    tools and members of the shed are not publicly available
    Public shed- Anyone can join and see who is in the shed and what tools are
    listed in the shed.
    """

    name = models.TextField(max_length = 50)
    description = models.TextField(max_length = 1000)
    private = models.BooleanField()
    address = models.ForeignKey('Address', unique = True)
    Members = models.ManyToManyField('Person')
    coordinator = models.ForeignKey('Person', related_name='+')
    Tools = models.ManyToManyField('Tool', blank = True, null = True, related_name='+')

    @classmethod
    def create(cls, name, address, coordinator, description, private):
        """
        Constructor for the Shed object.
        Takes in the name, address, coordinator, description and the private
        boolean at creation. The shed is initially created with no listed
        tools and the coordinator is automatically removed from the shed.
        Privacy can be changed at any time.
        """
        new_shed = Shed()
        new_shed.name = name
        new_shed.address = address
        new_shed.coordinator = coordinator
        new_shed.description = description
        new_shed.private = private
        new_shed.save()
        coordinator.join_shed(new_shed)
        coordinator.coordinate_shed(new_shed)
        return new_shed

    def make_private(self):
        self.private = True
        self.save()

    def make_public(self):
        self.private = False
        self.save()

    def is_private(self):
        return self.private

    def change_address(self, address):
        self.address = address
        self.address.save()
        self.save()

    def get_address(self):
        return self.address

    def set_coordinator(self, coordinator):
        self.coordinator = coordinator
        self.save()

    def get_coordinator(self):
        return self.coordinator

    def set_description(self, description):
        self.description = description
        self.save()

    def get_description(self):
        return self.description

    def add_member(self, User):
        self.Members.add(User)
        self.save()

    def remove_member(self, User):
        self.Members.remove(User)
        self.save()

    def add_tool(self, tool):
        self.Tools.add(tool)
        self.save()

    def remove_tool(self, Tool):
        self.Tools.remove(Tool)
        self.save()

    def privacy_to_string(self):
        if self.private:
            return "Private"
        return "Public"

class Tool(models.Model):
    """
    Class to represent the Tool object
    This class stores the owner, name, description, category, pickup arrangements
    and special instructions for the tool as well as a picture of the tool.
    This model also contains the location of the tool whether it be in a shed
    or shared from home.
    """
    name= models.CharField(max_length=50)
    description = models.CharField(max_length = 1000)
    category = models.CharField(max_length = 1000)
    pickup_arrangements = models.CharField(max_length = 1000)
    special_instructions = models.CharField(max_length = 1000)
    picture = models.FileField(upload_to="MEDIA_ROOT")
    in_a_shed = models.BooleanField(False)
    address = models.ForeignKey('Address',)
    shed = models.ForeignKey('Shed', blank = True, null = True)
    owner = models.ForeignKey('Person', related_name = '+')
    requesters = models.ManyToManyField('Person')
    reserved_dates = models.CharField(max_length = 30)
    borrower = models.ForeignKey('Person', blank = True, null = True, related_name = 'n')

    @classmethod
    def create(self, owner, name, description, category, p_u, s_i, picture, shed):
        """
        Constructor Method for the Tool Object.
        This constructor takes in the owner, name, description, category, pickup
        arrangements, special instructions and picture upon creation.
        """
        new_tool = Tool()
        new_tool.owner=owner
        new_tool.name=name
        new_tool.description=description
        new_tool.category=category
        new_tool.pickup_arrangements=p_u
        new_tool.special_instructions=s_i
        new_tool.picture=picture
        if p_u == "Home":
            new_tool.address=owner.address
            new_tool.shed = None
            new_tool.in_a_shed = False
            new_tool.save()
            return new_tool
        elif p_u =="Shed":
            new_tool.address=shed.address
            new_tool.in_a_shed = True
            new_tool.save()
            new_tool.add_to_shed(shed)
            return new_tool

    def no_conflict(self, start, end):
        """
        Takes parameters start and end, which represent how many days the
        start and end dates are from today. Returns true if there is NOT a conflict,
        false if there is.
        start and end dates will be strings in the format yyyy-mm-dd
        """
        lst = self.reservation_list()

        start_date = datetime.strptime(start, "%Y-%m-%d")
        end_date = datetime.strptime(end, "%Y-%m-%d")

        for x in range(start_date.toordinal()-start_date.toordinal(), end_date.toordinal()-start_date.toordinal()):
            if (len(lst)==0):
                return True
            if(lst[x] == '1'):
                return False
        return True

    def is_valid(self, start, end):
        """
        Checks the start and end dates to see if they are valid,
        e.g. Start date is not later than end date.
        start and end dates will be strings in the format yyyy-mm-dd
        """
        start_date = datetime.strptime(start, "%Y-%m-%d")
        end_date = datetime.strptime(end, "%Y-%m-%d")
        return(start_date.toordinal() <= end_date.toordinal())

    def add_reservation(self, start, end):
        """
        Adds a reservation for the dates start and end, which are integers
        representing the number of days away from today. Make sure to check
        no_conflict() before adding a reservation.
        """
        list = self.reservation_list()
        for x in range(start, end+1):
            list[x] = '1'
        self.reserved_dates = self.list_to_string(list)
        self.save()

    def reservation_list(self):
        list = []
        for char in self.reserved_dates:
            list.append(char)
        return list

    def list_to_string(self, list):
        s = ""
        for entry in list:
            s += entry
        self.reserved_dates = s
        self.save()

    def add_to_shed(self, shed):
        self.shed = shed
        self.location = shed.get_address()
        self.in_a_shed = True
        shed.add_tool(self)
        self.save()

    def remove_from_shed(self):
        self.shed.remove_tool(self)
        self.shed = None
        self.location = None
        self.in_a_shed = False
        self.save()


    def is_in_shed(self):
        return self.in_a_shed

    def set_location(self, address):
        self.location = address
        self.save()

    def set_instructions(self, instructions):
        self.special_instructions = instructions

    def set_pickup_arrangements(self, pickup_arrangements):
        self.pickup_arrangements = pickup_arrangements
        self.save()

    def set_description(self, description):
        self.description = description
        self.save()

    def set_category(self, category):
        self.category = category
        self.save()

    def set_picture(self, picture):
        self.picture = picture
        self.save()

    def set_name(self, name):
        self.name = name
        self.save()

    def get_instructions(self, instructions):
        return self.special_instructions

    def get_pickup_arrangements(self, pickup_arrangements):
        return self.pickup_arrangements

    def get_description(self, description):
        return self.description

    def get_category(self, category):
        return self.category

    def get_picture(self, picture):
        return self.picture

    def get_name(self, name):
        return self.name

class ToolRequest(models.Model):
    """
    "A ToolRequest object represents a request to borrow a tool from a certain user. This
    class stores the borrower, owner, tool, any messages between the requester and owner,
    start/end/return dates and boolean values indicating whether the request was accepted
    and whether the tool has been returned.
    """
    id = models.AutoField(primary_key = True)
    is_extension = models.BooleanField(default = False)
    is_tool = models.BooleanField(default = True)
    is_shed = models.BooleanField(default = False)
    is_confirmation = models.BooleanField(default = False)
    borrower = models.ForeignKey('Person', related_name = '+')
    owner = models.ForeignKey('Person', related_name = '+')
    tool = models.ForeignKey('Tool')
    request_accepted = models.BooleanField(False)
    start_date = models.DateField()
    end_date = models.DateField()
    date_returned = models.DateTimeField()
    request_message = models.CharField(max_length = 200)
    response_message = models.CharField(max_length = 200)
    tool_returned = models.BooleanField(False)

    @classmethod
    def create(self, sender, receiver, tool, start_date, end_date, message):
        new_request = ToolRequest()
        new_request.borrower = sender
        new_request.owner = receiver
        new_request.tool = tool
        new_request.start_date = start_date
        new_request.end_date = end_date
        new_request.request_message = message
        new_request.request_accepted = False
        new_request.date_returned = datetime.today()
        new_request.tool_returned = False
        new_request.save()
        receiver.tool_requests.add(new_request)
        return new_request


    def accept(self, message):
        self.request_accepted = True
        self.response_message = message
        self.tool.borrower = self.borrower
        self.tool.save()
        self.borrower.borrowed_tools.add(self.tool)
        self.save()

    def decline(self, message):
        self.request_accepted = False
        self.response_message = message
        self.save()

    def is_past_due(self):
        if self.date_returned == None:
            date= date.today()
        else:
            date = self.date_returned
        if date > self.end_date:
            return True
        else:
            return False

    def days_past_due(self):
        difference = date.today() - self.end_date
        days = difference.total_seconds() / 86400
        return days

    # called when a borrower says they returned the tool
    def borrower_returned_tool(self):
        # TODO: send request to owner
        self.date_returned = date.today()
        self.save()

    # called when an owner confirms that the tool is returned
    def owner_confirmed_return(self, change_date_returned, date):
        self.tool.borrower = None
        for t in self.borrower.borrowed_tools:
            if t.owner == self.owner and t.name == self.tool.name:
                self.borrower.borrowed_tools.remove(t)

        if change_date_returned:
            self.date_returned = date
            self.save()
        if self.is_past_due():
            days_late = self.days_past_due()
            self.borrower.add_strikes(days_late)
            self.borrower.save()
            self.tool_returned = True
            self.delete()
        else:
            self.tool_returned = True
            self.delete()


    def request_extension(self, new_date):
        # TODO: send request to owner
        self.save()

    def extend_date(self, new_date):
        self.end_date = new_date
        end = new_date - date.today()
        self.tool.add_reservation(0, end)
        self.save()


class ShedRequest(models.Model):
    """
    A ShedRequest object represents a request to join a shed from a certain user. This
    class stores the requester, shed, any messages between the requester and shed
    coordinator, and a boolean value indicating whether the request has been accepted.
    """
    id = models.AutoField(primary_key=True)
    is_extension = models.BooleanField(default = False)
    is_tool = models.BooleanField(default = False)
    is_shed = models.BooleanField(default = True)
    is_confirmation = models.BooleanField(default = False)
    requester = models.ForeignKey('Person')
    shed = models.ForeignKey('Shed')
    request_accepted = models.BooleanField()
    request_message = models.CharField(max_length = 200)
    response_message = models.CharField(max_length = 200)

    @classmethod
    def create(self, requester, shed, message):
        new_request = ShedRequest()
        new_request.requester = requester
        new_request.request_message = message
        new_request.shed = shed
        new_request.request_accepted = False
        new_request.save()
        shed.coordinator.shed_requests.add(new_request)
        return new_request

    def accept(self, message):
        self.request_accepted = True
        self.response_message = message
        self.requester.join_shed(self.shed)
        self.save()


    def decline(self, message):
        self.request_accepted = False
        self.response_message = message
        self.save()

class ExtensionRequest(models.Model):
    id = models.AutoField(primary_key = True)
    tool_request = models.ForeignKey('ToolRequest')
    is_extension = models.BooleanField(default = True)
    is_tool = models.BooleanField(default = False)
    is_shed = models.BooleanField(default = False)
    is_confirmation = models.BooleanField(default = False)
    request_message = models.CharField(max_length = 200)
    response_message = models.CharField(max_length = 200)
    new_end_date = models.DateField()

    @classmethod
    def create(self, tool_request, message, end_date):
        new_request = ExtensionRequest()
        new_request.tool_request = tool_request
        new_request.request_message = message
        new_request.new_end_date = end_date
        new_request.save()
        new_request.tool_request.owner.extension_requests.add(new_request)

    def accept(self, response_message):
        self.tool_request.extend_date(self.new_end_date)
        first = self.tool_request.owner.first_name
        last = self.tool_request.owner.last_name
        tool = self.tool_request.tool.name
        date = self.new_end_date
        message = "Your request to extend the loan of " + first + " " + last + "'s tool: " + tool + " until the date: " + date + " has been accepted!"
        if(response_message != ""):
            message += " Here is a message from "+ first + " " + response_message
        note = Notification.create(self, self.tool_request.borrower, message, 1)

    def decline(self, response_message):
        first = self.tool_request.owner.first_name
        last = self.tool_request.owner.last_name
        tool = self.tool_request.tool.name
        date = self.new_end_date
        message = "Your request to extend the loan of " + first + " " + last + "'s tool: " + tool + " until the date: " + date + " has been declined"
        if(response_message != ""):
            message += " Here is a message from "+ first + " " + response_message
        note = Notification.create(self, self.tool_request.borrower, message, 2)

class ConfirmationRequest(models.Model):
    id = models.AutoField(primary_key = True)
    is_confirmation = models.BooleanField(default = True)
    is_extension = models.BooleanField(default = False)
    is_tool = models.BooleanField(default = False)
    is_shed = models.BooleanField(default = False)
    tool_request = models.ForeignKey('ToolRequest')
    response_message = models.CharField(max_length = 200)

    @classmethod
    def create(self, tool_request):
        new_request = ConfirmationRequest()
        new_request.tool_request = tool_request
        new_request.save()
        new_request.tool_request.owner.confirmation_requests.add(new_request)

    def accept(self, response_message):
        self.tool_request.owner_confirmed_return
        first = self.tool_request.owner.first_name
        last = self.tool_request.owner.last_name
        tool = self.tool_request.tool.name
        message = first + " " + last + " has confirmed that you returned the tool: " + tool
        if(response_message != ""):
            message += " Here is a message from "+ first + " " + response_message
        note = Notification.create(self.tool_request.owner, message, 1)

    def decline(self, response_message):
        first = self.tool_request.owner.first_name
        last = self.tool_request.owner.last_name
        tool = self.tool_request.tool.name
        message = first + " " + last + " has not yet received the tool: " + tool
        if(response_message != ""):
            message += " Here is a message from "+ first + " " + response_message
        note = Notification.create(self.tool_request.owner, message, 2)