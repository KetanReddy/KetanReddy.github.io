'''
Created on Sep 11, 2014

'''
from math import *

"""
Calculate the great circle distance between two points 
on the earth. Takes in two arrays of strings returned by the
google.py geocoder functions. 
"""
def CalcDist(Set1, Set2):

    "Parsing the input data"
    long1 = Set1[1]
    lat1 = Set1[0]
    long2 = Set2[1]
    lat2 = Set2[0]
    
    
    "Converting the latitude and longitude into floats (So they can be converted into Radians"
    long1=float(long1)
    long2=float(long2)
    lat1=float(lat1)
    lat2=float(lat2)
    
    "Convert the floats to their radian equivilant"
    long1=radians(long1)
    long2=radians(long2)
    lat1=radians(lat1)
    lat2=radians(lat2)

    "Haversine Formula"
    distlong = long2 - long1 
    distlat = lat2 - lat1 
    X = sin(distlat/2)**2 + cos(lat1) * cos(lat2) * sin(distlong/2)**2
    Y = 2 * asin(sqrt(X)) 
    Dist = 6367 * Y     # 6367 is the radius of the Earth in kilometers 
    
    "Final Conversions to Imperial units"
    Dist=Dist*0.621371  #Translating the Distance to Miles.
    Dist=str(Dist)      #Making the distance a string 
    return Dist 