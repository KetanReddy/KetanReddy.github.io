==================
pygeocoder 1.2.5
==================
Origonal Author Xiao Yu

*Based on googlemaps 1.0.2 by John Kleint*

Modified by Ketan Reddy to be compatible with Python 3

README
------
About
=====

Python-Geocoder is a simple library that uses Google Maps APIs for geocoding.


Usage
=====

As python library::

    >>> from geocode.google import GoogleGeocoderClient
    
    >>> geocoder = GoogleGeocoderClient(False) # must specify sensor parameter explicitely
    >>> result = geocoder.geocode("massasauga park")
    
    >>> result.is_success()
    True
    
    >>> len(result)
    3
    
    # by default all get_* methods will fetch the first result:
    >>> result.get_formatted_address()
    u'The Massasauga Provincial Park, The Archipelago, ON, Canada'
    
    # but you can also pass it index parameter:
    >>> result.get_formatted_address(2)
    u'Massasauga Prairie Nature Preserve, Roseville, IL 61417, USA'
    
    >>> result.get_location()
    (Decimal('45.19526590'), Decimal('-80.05372229999999'))
    
    >>> result.get_location_type()
    u'APPROXIMATE'
    
    # each result is a dictionary based on Google geocoding API specification
    >>> for r in result: print r["formatted_address"]
    The Massasauga Provincial Park, The Archipelago, ON, Canada
    The Massasauga Provincial Park, RR 2, Parry Sound, ON P0G, Canada
    Massasauga Prairie Nature Preserve, Berwick, IL 61417, USA
    
    

geocode/google-geocoder.py is a command line tool. A sample usage::

    $ python geocode/google.py -a "massasauga park"
    The Massasauga Provincial Park, The Archipelago, ON, Canada (45.19526590, -80.05372229999999) - APPROXIMATE
    The Massasauga Provincial Park, RR 2, Parry Sound, ON P0G, Canada (45.1969970, -80.0398220) - APPROXIMATE
    Massasauga Prairie Nature Preserve, Roseville, IL 61417, USA (40.76002530, -90.57780330) - APPROXIMATE

License
------
BSD

Dependencies
------------
It has dependency on the json module, included with Python versions 2.6 and later and available for download as simplejson for earlier versions. functools is needed and included in Python 2.5. Requirement for hmac is included with Python 2.2. hashlib depends on Python 2.5. base64 depends on Python 2.4.

requests library is needed and installed by setuptools.

It is developed on Python 2.7 but should work on earlier versions. It is also compatible with Python 3.


Usage
-----
Please refer to http://code.xster.net/pygeocoder/wiki for help with usage


Contact Information
-------------------
Author: Xiao Yu
Internet: http://code.xster.net/pygeocoder

For comments, issues, requests, please contact via BitBucket at the above website


Changelog
---------
Version 1.3
Updated to work with Python 3

Version 1.2.5
More business key fix

Version 1.2.4
Business key signing fix

Version 1.2.3.1
Some pep8 cleanup

Version 1.2.3
Fixed business key crypto error
Added back simple API authentication method

Version 1.2.2
Added components restrictions in searches and location type getter in result

Version 1.2.1.1
Another dependency fix

Version 1.2.1
Proxy support

Version 1.2.0.3
setup.py dependency fix

Version 1.2.0.2
Minor setup.py Python 3 fix

Version 1.2.0.1
setup.py dependency fix

Version 1.2
Refactor and unit testing
Changed license to BSD
Python 3 compatibility
Business API account support

Version 1.1.4
Fixed UTF-8 and facilitated command line usage

Version 1.1.3
Made Geocoder methods static method while backward compatible

Version 1.1.2
Added address validation

Version 1.1.1
Returns GeocoderResult by default.
Result set accessible by iterator or index.

Version 1.1
Added GeocoderResult in order to ease field retrieval/result parsing.

Version 1.0
Working version an API V3.



For more usage information run::

    $ python geocode/google.py --help
